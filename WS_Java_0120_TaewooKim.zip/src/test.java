
public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "Hello";
		String str2 = "Hello";
		if(str == str2) {
			System.out.println("같음");
		}
		else
			System.out.println("다름");
	}

}
